package routes

import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import models.Compania
import models.Modelo
import java.io.File

// Archivo donde se almacenarán los datos
private const val DATA_FILE_PATH = "E:\\POLI\\septimo_semestre\\Moviles\\users.json"

// Función para guardar los datos en un archivo
fun saveCompaniasToFile(companias: List<Compania>) {
    val json = Json.encodeToString(ListSerializer(Compania.serializer()), companias)
    File(DATA_FILE_PATH).writeText(json)
}

fun loadCompaniasFromFile(): MutableList<Compania> {
    val file = File(DATA_FILE_PATH)
    return if (file.exists() && file.readText().isNotEmpty()) {
        val json = file.readText()
        Json.decodeFromString<MutableList<Compania>>(json)
    } else {
        mutableListOf()
    }
}

// Lista de compañías cargada desde el archivo
private val companias = loadCompaniasFromFile()

fun Route.companiaRouting() {
    route("/companias") {
        get {
            if (companias.isNotEmpty()) {
                call.respond(companias)
            } else {
                call.respondText("No hay compañías", status = HttpStatusCode.OK)
            }
        }

        get("{id?}") {
            val id = call.parameters["id"] ?: return@get call.respondText(
                "Id no encontrado",
                status = HttpStatusCode.BadRequest
            )
            val compania = companias.find { it.id == id.toInt() } ?: return@get call.respondText(
                "Compañía con $id no encontrada",
                status = HttpStatusCode.NotFound
            )
            call.respond(compania)
        }

        post {
            val compania = call.receive<Compania>()
            companias.add(compania)
            saveCompaniasToFile(companias)
            call.respondText("Compañía creada correctamente", status = HttpStatusCode.Created)
        }

        delete("{id?}") {
            val id = call.parameters["id"] ?: return@delete call.respondText(
                "Id no encontrado",
                status = HttpStatusCode.BadRequest
            )
            if (companias.removeIf { it.id == id.toInt() }) {
                saveCompaniasToFile(companias)
                call.respondText("Compañía eliminada correctamente", status = HttpStatusCode.Accepted)
            } else {
                call.respondText("No encontrada", status = HttpStatusCode.NotFound)
            }
        }

        put("{id?}") {
            val id = call.parameters["id"] ?: return@put call.respondText(
                "Id no encontrado",
                status = HttpStatusCode.BadRequest
            )
            val updatedCompania = call.receive<Compania>()
            val companiaIndex = companias.indexOfFirst { it.id == id.toInt() }

            if (companiaIndex == -1) {
                return@put call.respondText("Compañía con $id no encontrada", status = HttpStatusCode.NotFound)
            }

            companias[companiaIndex] = updatedCompania
            saveCompaniasToFile(companias)
            call.respondText("Compañía actualizada correctamente", status = HttpStatusCode.OK)
        }
    }

    route("/companias/{id}/modelos") {
        get {
            val id = call.parameters["id"] ?: return@get call.respondText(
                "Id de compañía no encontrado",
                status = HttpStatusCode.BadRequest
            )
            val compania = companias.find { it.id == id.toInt() } ?: return@get call.respondText(
                "Compañía con $id no encontrada",
                status = HttpStatusCode.NotFound
            )
            call.respond(compania.modelos)
        }

        post {
            val id = call.parameters["id"] ?: return@post call.respondText(
                "Id de compañía no encontrado",
                status = HttpStatusCode.BadRequest
            )
            val companiaIndex = companias.indexOfFirst { it.id == id.toInt() }

            if (companiaIndex == -1) {
                return@post call.respondText("Compañía con $id no encontrada", status = HttpStatusCode.NotFound)
            }

            val newModelo = call.receive<Modelo>()
            val compania = companias[companiaIndex]

            // Agregar el nuevo modelo a la lista de modelos existentes
            val updatedCompania = compania.copy(modelos = compania.modelos + newModelo)
            companias[companiaIndex] = updatedCompania
            saveCompaniasToFile(companias)
            call.respondText("Modelo añadido correctamente", status = HttpStatusCode.Created)
        }

        put("{modeloId?}") {
            val id = call.parameters["id"] ?: return@put call.respondText(
                "Id de compañía no encontrado",
                status = HttpStatusCode.BadRequest
            )
            val companiaIndex = companias.indexOfFirst { it.id == id.toInt() }

            if (companiaIndex == -1) {
                return@put call.respondText("Compañía con $id no encontrada", status = HttpStatusCode.NotFound)
            }

            val updatedModelos = call.receive<List<Modelo>>()
            val compania = companias[companiaIndex]

            // Actualizar solo los modelos de la compañía
            val updatedCompania = compania.copy(modelos = updatedModelos)
            companias[companiaIndex] = updatedCompania
            saveCompaniasToFile(companias)
            call.respondText("Modelos actualizados correctamente", status = HttpStatusCode.OK)
        }

        delete("{modeloId}") {
            val id = call.parameters["id"] ?: return@delete call.respondText(
                "Id de compañía no encontrado",
                status = HttpStatusCode.BadRequest
            )
            val companiaIndex = companias.indexOfFirst { it.id == id.toInt() }

            if (companiaIndex == -1) {
                return@delete call.respondText("Compañía con $id no encontrada", status = HttpStatusCode.NotFound)
            }

            val modeloId = call.parameters["modeloId"] ?: return@delete call.respondText(
                "Id de modelo no encontrado",
                status = HttpStatusCode.BadRequest
            )
            val compania = companias[companiaIndex]
            val modeloIndex = compania.modelos.indexOfFirst { it.id == modeloId.toInt() }

            if (modeloIndex == -1) {
                return@delete call.respondText("Modelo con $modeloId no encontrado", status = HttpStatusCode.NotFound)
            }

            // Eliminar el modelo de la lista
            val updatedModelos = compania.modelos.toMutableList().apply { removeAt(modeloIndex) }
            val updatedCompania = compania.copy(modelos = updatedModelos)
            companias[companiaIndex] = updatedCompania
            saveCompaniasToFile(companias)

            call.respondText("Modelo eliminado correctamente", status = HttpStatusCode.OK)
        }
    }
}