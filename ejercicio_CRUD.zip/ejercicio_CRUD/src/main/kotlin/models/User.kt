package models

import kotlinx.serialization.Serializable

@Serializable
data class Modelo(
    val id: Int,
    val nombre: String,
    val precio: Double, // Decimal
    val tipo: String, // String
    val esElectrico: Boolean // Booleano
)

@Serializable
data class Compania(
    val id: Int,
    val nombre: String,
    val anioFundacion: Int, // Entero
    val esPublica: Boolean, // Booleano
    val paisOrigen: String, // String
    val numeroTotalModelos: Int, // Entero
    val modelos: List<Modelo>
)